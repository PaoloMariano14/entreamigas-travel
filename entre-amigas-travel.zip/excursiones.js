const excursiones = [
  {
    nombre: "Isla Saona VIP",
    descripcion: "Un día inolvidable en el paraíso con bebidas incluidas, almuerzo y snorkel.",
    imagen: "assets/saona.jpg",
    whatsapp: "https://wa.me/1234567890?text=Hola%2C%20quiero%20reservar%20la%20excursión%20a%20Isla%20Saona%20VIP"
  },
  {
    nombre: "Cascada El Limón",
    descripcion: "Aventura en caballo y caminata hasta la impresionante cascada en Samaná.",
    imagen: "assets/limon.jpg",
    whatsapp: "https://wa.me/1234567890?text=Hola%2C%20quiero%20reservar%20la%20excursión%20a%20la%20Cascada%20El%20Limón"
  },
  {
    nombre: "City Tour Santo Domingo",
    descripcion: "Recorrido cultural por la Zona Colonial y puntos históricos.",
    imagen: "assets/santo-domingo.jpg",
    whatsapp: "https://wa.me/1234567890?text=Hola%2C%20quiero%20reservar%20el%20City%20Tour%20por%20Santo%20Domingo"
  }
];

const container = document.getElementById('excursiones-container');

excursiones.forEach(exc => {
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <img src="${exc.imagen}" alt="${exc.nombre}" />
    <div class="card-body">
      <h3>${exc.nombre}</h3>
      <p>${exc.descripcion}</p>
      <a href="${exc.whatsapp}" class="btn-whatsapp" target="_blank">Reservar por WhatsApp</a>
    </div>
  `;
  container.appendChild(card);
});
